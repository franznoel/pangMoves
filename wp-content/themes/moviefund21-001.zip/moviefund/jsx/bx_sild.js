$(document).ready(function(){
  $('.slider1').bxSlider({
    slideWidth: 200,
    minSlides: 8,
    maxSlides: 8,
    slideMargin: 10
  });
});