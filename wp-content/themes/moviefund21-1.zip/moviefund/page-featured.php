<?php 
/*
Template Name: Featured PlanetX
*/
get_header();?>      

         <div class="how-it-works text-center" id="how">
            	<div class="container">
                	<h2 class="white">How It Works</h2>
                    <div class="button">
                    	<ul class="list-inline">
                        	<li><a class="btn btn-7">FILM MAKERS</a></li>
                            <li><a class="btn btn-5 active-ihwit"> INVESTORS</a></li>
                        </ul>
                    </div><br/>
                    <div class="row">
<div class="mob-center lar-view">
			<div class="col-md-12">
                           <div id="invest" class="how_steps set-posi1 hw-show">
                           <div class="slider4">
                           <?php how_it_inves();?> </div></div> 
                           <div id="film-ker" class="how_steps set-posi2 hw-hide">
                           <div class="slider4">
                           <?php how_it();?>
                           </div></div> </div></div>
<div class="mob-center mob-view">
			<div class="col-md-12">
                           <div class="how_steps set-posi1">
                           <div class="slider2">
                           <?php how_it_inves();?></div></div> 
                           <div class="how_steps set-posi2 hw-hide">
                           <div class="slider2">
                           <?php how_it();?>
                           </div></div> </div></div></div></div></div>

            <!--<div class="top-share">

            	<div class="container">

                	<div class="row">

                    	<div class="col-sm-3">

                        	<div class="share-count">

                                <a class="btn btn-41" href="<?php echo of_get_option('join'); ?>">Join</a>

                            </div>

                        </div>

                        <div class="col-sm-6 col-sm-offset-3">

                        	<div class="clogin-with-social">

                                <ul class="list-inline">

                                	<li><a href="<?//php echo of_get_option('linkedin'); ?>"><img src="<?php echo get_home_url();?>/wp-content/uploads/2015/09/sign-in.png" alt="Img"></a></li>

                                    <li><a href="<?//php echo of_get_option('facebook'); ?>"><img src="<?php echo get_home_url();?>/wp-content/uploads/2015/09/sign-fb.png" alt="Img"></a></li>

                                    <li><a href="<?//php echo of_get_option('twitter'); ?>"><img src="<?php echo get_home_url();?>/wp-content/uploads/2015/09/sign-tw.png" alt="Img"></a></li>

                                </ul>

                            </div>

                        </div>

                    </div>

                </div>

            </div>-->

            

            <div class="feat-holder planetx" id="plan">

            	<div class="title text-center">

                    <h2>Featured Project: Planet X</h2>

                    <br/>

                </div>

            	<div class="container">

                    <div class="row">

					<?php featureditem();?>

                    </div>

                </div>

            </div>


<?php get_footer(); ?>


