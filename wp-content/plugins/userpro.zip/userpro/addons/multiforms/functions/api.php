<?php

class userpro_mu_api {

	function __construct() {

	}
	
}

$userpro_mutli = new userpro_mu_api();