=== Jeba Ajax mailchimp ===
Tags: mailchimp, Ajax mailchimp, awesome mailchimp, jeba mailchimp, mailchimp form, ajax mailchimp form, user subscription form
Requires at least: 3.0.1
Tested up to: 4.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Jeba Ajax mailchimp is an awesome mailchimp form to user subscription, super lightweight plugin for your wordpress website mailchimp. 

== Description ==

This plugin will enable awesome mailchimp in your wordpress theme. You can use the jeba Ajax mailchimp via shortcode in everywhere you want, even in theme files. 

Wanna see how it works? Click here: http://prowpexpert.com/jeba-ajax-mailchimp/

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `plugin-directory` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use shortcode in page, post or in widgets.
4. If you want use the jeba Ajax mailchimp in your theme php, Place `<?php echo do_shortcode('[jeba_mailchimp]'); ?>` in your templates.
5. In the [jeba_mailchimp] shortcode you can change formaction="", title1="", title1="", submit=" "
6. You have got a tiny mce button on your wordpress editor after activation this plugin.

<strong>Use Jeba Ajax mailchimp shortcode</strong>
<pre>[jeba_mailchimp]</pre>

<strong>Here can change</strong>
<pre>[jeba_mailchimp formaction=" " title1=" " title1=" " submit=" "]</pre>

== Frequently Asked Questions ==
= How can get formaction? =
This is real <form action=""> You can get in mailchimp embed code.



== Screenshots ==

1. Installed in demo server.
2. Another demo.



== Changelog ==

= 1.0 =
* Initial Release