jQuery(document).ready( function() {

	jQuery('form#newsletter-form').formchimp({
		//'appendElement' : "h1",
		'buttonText' : 'Thanks',
		//'errorMessage' : "Error message",
		//'responseClass' : "mc-response",
		//'successMessage' : "Send message",
		//'url': actionUrl,
	});

});